﻿# Administration Windows Server 2016
# ESGI 2A - Mélodie BERNARD, Jacques RIMBAULT, Antoine HENRY

# Audit et modification en masse de permissions NTFS sur un répertoire Windows

# Syntaxe : .\NTFS.ps1 -Action '[ ACL | Audit | Child-Audit | Help | High | Medium | Low ]' -Path '[Directory]' -Path2 '[Directory]' -Recurse '[yes]' -Account '[Account]'

[CmdletBinding()]
Param (
	[Parameter(Mandatory=$True,Position=0)]
    [String]$Action,
	[String]$Path,
	[Parameter(Mandatory=$False)]
	[String]$Path2,
    [String]$Recurse,
	[String]$Account
)

# Encodage UTF-8 E/S
$OutputEncoding = New-Object -typename System.Text.UTF8Encoding
[Console]::OutputEncoding = New-Object -typename System.Text.UTF8Encoding

# Modification de la politique d'exécution Powershell (en attente de la signature numérique)
Set-ExecutionPolicy Unrestricted -Force 

# Définir la langue du système
$infos = Get-WmiObject Win32_OperatingSystem -ComputerName '.'
$Language = $infos.OSLanguage

# Identification des objets de type "Comptes d'utilisateurs"
if($Language -eq 1036) {
    $admins = "Administrateurs"
    $users  = "Utilisateurs"
    $usersA = "Utilisateurs Authentifiés"
    $system = "Système"  
}elseif($Language -eq 1033) {
    $admins = "Administrators"
    $users  = "Users"
    $usersA = "Authenticated Users"
    $system = "System"
}else{
    Write-Host "OS Language compatibility error !" 
}

# Identification des objets de type "Accès"
$accessArray = 'None', 'ReadData', 'ListDirectory', 'CreateFiles', 'CreateDirectories', 'AppendData', 'ReadExtendedAttributes', 'WriteExtendedAttributes', 'Traverse', 'ExecuteFile', 'DeleteSubdirectoriesAndFiles', 'ReadAttributes', 'WriteAttributes', 'Write', 'Delete', 'ReadPermissions', 'Read', 'ReadAndExecute', 'Modify', 'ChangePermissions', 'TakeOwnership', 'Synchronize', 'FullControl', 'GenericAll', 'GenericExecute', 'GenericWrite', 'GenericRead'

# Affichage de l'aide
if($Action -eq 'Help'){
    Clear
    Write-Host
    foreach($line in (Get-Content -Path 'doc/help.txt')){
        Write-Host $line 
    }
    Write-Host
}

# Installation du module NTFS Security
if($Action -ne 'Help'){
    if(Get-Module -ListAvailable -Name NTFSSecurity) {
        if($Language -eq 1036){
            Write-Host
	        Write-Host "Démarrage du module NTFSSecurity..."
	        Write-Host
        }elseif($Language -eq 1033){
	        Write-Host
	        Write-Host "Launching NTFSSecurity module..."
	        Write-Host
        }
    }else{
        if($Language -eq 1036){
	        Write-Host
	        Write-Host "Installation du module NTFSSecurity nécessaire."
	        Write-Host "Démarrage de l'installation du module NTFSSecurity..."
	        Write-Host
            Install-Module NTFSSecurity -Force
	        Write-Host
	        Write-Host "Le module NTFSSecurity est installé."
	        Write-Host "Démarrage du module NTFSSecurity..."
	        Write-Host
        }elseif($Language -eq 1033){
            Write-Host
	        Write-Host "NTFSSecurity module installation needed."
	        Write-Host "Launching NTFSSecurity module installation..."
	        Write-Host
            Install-Module NTFSSecurity -Force
	        Write-Host
	        Write-Host "NTFSSecurity module is installed."
	        Write-Host "Launching NTFSSecurity module..."
	        Write-Host
        }	
    }
}

# Détection des fichiers
if($Action -ne 'Help'){
    if($Language -eq 1036){
        Write-Host "     Détection des fichiers..."
    }elseif($Language -eq 1033){
        Write-Host "     Detecting files..."
    }
    $begincountdate = Get-Date
    if($Recurse -and $Path2){
        foreach($file in ($ChildItemRecurse = Get-ChildItem -Path $Path2 -recurse)){ $counter++ }
    }elseif($Recurse){
        foreach($file in ($ChildItemRecurse = Get-ChildItem -Path $Path -recurse)){ $counter++ } 
    }else{
        $counter = (($ChildItem = Get-ChildItem -Path $Path) | Measure-Object -Line).lines
    }
    $endcountdate = Get-Date
    $counttime = ($endcountdate - $begincountdate)
    if($Language -eq 1036){
        Write-Host "     Nombre de fichiers détectés : $counter."
        Write-Host "     Détection effectuée en : $counttime."
        Write-Host
    }elseif($Language -eq 1033){
        Write-Host "     Number of files detected : $counter."
        Write-Host "     Detection performed in : $counttime."
        Write-Host
    }
}
#  Application d'une ACL sous la forme d'un fichier texte créé par l'utilisateur
if($Action -eq "ACL") {
    Write-Host "(~)  Chargement des ACL contenues dans $Path..."
    Write-Host
    $lineacl = 0
    $begininvoke = Get-Date
    foreach($line in (Get-Content -Path $Path)){
        $lineacl++
        if($line[0] -ne '#' -and $line -ne '' -and $line[0] -ne ' ' -and $line[0] -ne ''){
            $ACLUser = $line.split(" ")[0]
            $ACLUser = $ACLUser.replace("_", " ")

            $ACLRight = $line.split(" ")[1]
            if($ACLRight -ne 'Allow' -and $ACLRight -ne 'Deny'){ 
                $ACLRight = "error" 
            }
                
            $ACLAccess = $line.split(" ")[2]
            if(!($accessArray -match $ACLAccess)){
                $ACLAccess = "error" 
            } 

            if($ACLRight -ne "error" -and $ACLAccess -ne "error"){
                if($Recurse){
                    if($ACLRight -eq "Allow"){
                        Write-Host "     Attribution récursive de droits $ACLAccess pour $ACLUser sur le répertoire $Path2..." 
                        Add-NTFSAccess -Path $Path2 -Account $ACLUser -AccessRights $ACLAccess
                        $ChildItemRecurse | Add-NTFSAccess -Account $ACLUser -AccessRights $ACLAccess
                    }elseif($ACLAccess -eq "Deny"){
                        Write-Host "     Suppression récursive de droits $ACLAccess pour $ACLUser sur le répertoire $Path2..."
                        Remove-NTFSAccess -Path $Path2 -Account $ACLUser -AccessRights $ACLAccess
                        $ChildItemRecurse | Remove-NTFSAccess -Account $ACLUser -AccessRights $ACLAccess
                    }
                }else{
                    if($ACLRight -eq "Allow"){
                        Write-Host "     Attribution de droits $ACLAccess pour $ACLUser sur le répertoire $Path2..." 
                        Add-NTFSAccess -Path $Path2 -Account $ACLUser -AccessRights $ACLAccess
                    }elseif($ACLAccess -eq "Deny"){
                        Write-Host "     Suppression de droits $ACLAccess pour $ACLUser sur le répertoire $Path2..."
                        Remove-NTFSAccess -Path $Path2 -Account $ACLUser -AccessRights $ACLAccess
                    }
                }
            }elseif($ACLRight -eq "error"){
                if($ACLAccess -eq "error"){
                    Write-Host "(!)  Ligne $lineacl : Erreurs détectées (Right et Access) dans le fichier ACL $Path"
                }else{
                    Write-Host "(!)  Ligne $lineacl : Erreur détectée (Right) dans le fichier ACL $Path" 
                }
            }elseif($ACLAccess -eq "error"){
                if($ACLRight -eq "error"){
                    Write-Host "(!)  Ligne $lineacl : Erreurs détectées (Right et Access) dans le fichier ACL $Path"
                }else{
                    Write-Host "(!)  Ligne $lineacl : Erreur détectée (Access) dans le fichier ACL $Path" 
                }         
            }
        } 
    }
    $endinvoke = Get-Date
    $invoketime = $endinvoke - $begininvoke
    Write-Host
    if($Language -eq 1036){
        Write-Host "     Permissions délivrées en : $invoketime."
        Write-Host
        if($Recurse){
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path2' pour vérifier les nouvelles permissions."
        }else{
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Audit' -Path '$Path2' pour vérifier les nouvelles permissions."
        }
	}elseif($Language -eq 1033){
        Write-Host "    Permissions issued in : $invoketime."
        Write-Host
        if($Recurse){
		    Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path2' to verify new permissions."
        }else{
            Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Audit' -Path '$Path2' to verify new permissions."
        }
	}
   	Write-Host   
}

# Politique de sécurité faible
if ($Action -eq "Low") {
   	if($Language -eq 1036){
		Write-Host "(?)  Politique de sécurité faible :"
   		Write-Host "     $admins : Contrôle total"
   		Write-Host "     $usersA : Modification" 
   		Write-Host "     $users : Modification"
		Write-Host
		Write-Host "(!)  Application des paramètres du niveau de sécurité $Action sur '$Path'."
        Write-Host
	}elseif($Language -eq 1033){
		Write-Host "(?)  Low security level :"
		Write-Host "     $admins : Full Control" 
   		Write-Host "     $usersA : Modification"
   		Write-Host "     $users : Modification"
		Write-Host
		Write-Host "(!)  Applying new security level $Action settings on '$Path'."
        Write-Host
	}
    $begininvoke = Get-Date
   	Invoke-Expression "levels\low-sec.ps1 -Path '$Path' -Recurse '$Recurse' -Account '$Account' -Language '$Language'"
    $endinvoke = Get-Date
    $invoketime = $endinvoke - $begininvoke
   	if($Language -eq 1036){
        Write-Host "     Permissions délivrées en : $invoketime."
        Write-Host
        if($Recurse){
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path' pour vérifier les nouvelles permissions."
        }else{
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Audit' -Path '$Path' pour vérifier les nouvelles permissions."
        }
	}elseif($Language -eq 1033){
        Write-Host "    Permissions issued in : $invoketime."
        Write-Host
        if($Recurse){
		    Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path' to verify new permissions."
        }else{
            Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Audit' -Path '$Path' to verify new permissions."
        }
	}
   	Write-Host
}

# Politique de sécurité modérée
if ($Action -eq "Medium") {
   	if($Language -eq 1036){
		Write-Host "(?)  Politique de sécurité modérée :"
   		Write-Host "     $admins : Contrôle total" 
   		Write-Host "     $usersA : Lecture et exécution"
   		Write-Host "     $users : Lecture et exécution"
		Write-Host
		Write-Host "(!)  Application des paramètres du niveau de sécurité $Action sur '$Path'."
        Write-Host
	}elseif($Language -eq 1033){
		Write-Host "(?)  Medium security level :"
		Write-Host "     $admins : Full Control" 
   		Write-Host "     $usersA : Read and execute"
   		Write-Host "     $users : Read and execute"
		Write-Host
		Write-Host "(!)  Applying new security level $Action settings on '$Path'."
        Write-Host
	}
    $begininvoke = Get-Date
   	Invoke-Expression "levels\medium-sec.ps1 -Path '$Path' -Recurse '$Recurse' -Account '$Account' -Language '$Language'"
   	$endinvoke = Get-Date
    $invoketime = $endinvoke - $begininvoke
    if($Language -eq 1036){
        Write-Host "     Permissions délivrées en : $invoketime."
        Write-Host
		if($Recurse){
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path' pour vérifier les nouvelles permissions."
        }else{
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Audit' -Path '$Path' pour vérifier les nouvelles permissions."
        }
	}elseif($Language -eq 1033){
        Write-Host "     Permissions issued in : $invoketime."
        Write-Host
		if($Recurse){
		    Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path' to verify new permissions."
        }else{
            Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Audit' -Path '$Path' to verify new permissions."
        }
	}
   	Write-Host
}

# Politique de sécurité élevée
if ($Action -eq "High") {
	if($Language -eq 1036){
   		Write-Host "(?)  Politique de sécurité élevée :"
   		Write-Host "     $admins : Contrôle total" 
   		Write-Host "     $usersA : Lecture seule"
   		Write-Host "     $users : Aucun droit"
		Write-Host
		Write-Host "(!)  Application des paramètres du niveau de sécurité $Action sur '$Path'."
        Write-Host
	}elseif($Language -eq 1033){
		Write-Host "(?)  High security level :"
   		Write-Host "     $admins : Full Control" 
   		Write-Host "     $usersA : Read-Only"
   		Write-Host "     $users : None Rights"
		Write-Host
		Write-Host "(!)  Applying new security level $Action settings on '$Path'."
        Write-Host
	}
    $begininvoke = Get-Date
   	Invoke-Expression "levels\high-sec.ps1 -Path '$Path' -Recurse '$Recurse' -Account '$Account' -Language '$Language'"
    $endinvoke = Get-Date
    $invoketime = $endinvoke - $begininvoke
   	if($Language -eq 1036){
        Write-Host "     Permissions délivrées en : $invoketime."
        Write-Host
		if($Recurse){
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path' pour vérifier les nouvelles permissions."
        }else{
            Write-Host "(OK) Exécuter .\NTFS.ps1 -Action 'Audit' -Path '$Path' pour vérifier les nouvelles permissions."
        }
	}elseif($Language -eq 1033){
        Write-Host "    Permissions issued in : $invoketime."
        Write-Host
		if($Recurse){
		    Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Child-Audit' -Path '$Path' to verify new permissions."
        }else{
            Write-Host "(OK) Execute .\NTFS.ps1 -Action 'Audit' -Path '$Path' to verify new permissions."
        }
	}
   	Write-Host
}

# Audit (récursif ou non) des permissions NTFS du dossier et de ses enfants
if ($Action -eq "Child-Audit") { 
	if($Language -eq 1036){
        if($Recurse){
		    Write-Host "(~)  Audit récursif des permissions NTFS des enfants du répertoire '$Path'"
        }else{
            Write-Host "(~)  Audit des permissions NTFS des enfants du répertoire '$Path'"
        }
    }elseif($Language -eq 1033){
        if($Recurse){
		    Write-Host "(~)  '$Path' children's NTFS permissions recursive audition."
        }else{
            Write-Host "(~)  '$Path' children's NTFS permissions audition."
        }
	}
	if($Language -eq 1036){
        Write-Host "     Importation des permissions NTFS des enfants du dossier..."
    }elseif($Language -eq 1033){
        Write-Host "     Importing child NTFS permissions from folder..."
    }
	$beginprintdate = Get-Date
	if($Recurse){
        foreach($file in ($ChildItemRecurse | Get-NTFSAccess | Select-Object -Property Name, Account, AccessRights, Length | Sort-Object -Property Name, Account | Out-GridView -Title "Audit récursif des permissions NTFS des enfants du répertoire '$Path'")) {Write-Host "OK"}
    }else{
        $ChildItem | Get-NTFSAccess | Select-Object -Property Name, Account, AccessRights, Length | Sort-Object -Property Name, Account | Out-GridView
	}
    $endprintdate = Get-Date
	$printtime = ($endprintdate - $beginprintdate)
	$audittime = $counttime + $printtime
	if($Language -eq 1036){
        Write-Host "     Importation effectuée en : $printtime."
	    Write-Host
	    Write-Host "(OK) Audit effectué en : $audittime."
	    Write-Host
    }elseif($Language -eq 1033){
        Write-Host "     Importation performed in : $printtime."
        Write-Host
        Write-Host "(OK) Audit performed in : $audittime."
        Write-Host
    }
}

# Audit des permissions NTFS du dossier
if ($Action -eq "Audit") {
	if($Language -eq 1036){
		Write-Host "(~)  Audit des permissions NTFS du répertoire '$Path'"
        Write-Host
	}elseif($Language -eq 1033){
		Write-Host "(~)  '$Path' NTFS permissions audition."
        Write-Host
	}
	$begincountdate = Get-Date
	$counter = ($ChildItem | Measure-Object -Line).lines
	$endcountdate = Get-Date
	$counttime = ($endcountdate - $begincountdate)
	if($Language -eq 1036){
        Write-Host "     Importation des permissions NTFS du dossier..."
    }elseif($Language -eq 1033){
        Write-Host "     Importing child NTFS permissions from folder..."
    }
	$beginprintdate = Get-Date
	Get-NTFSAccess | Select-Object -Property Name, Account, AccessRights, Length | Sort-Object -Property Name, Account | Out-GridView
	$endprintdate = Get-Date
	$printtime = ($endprintdate - $beginprintdate)
	$audittime = $counttime + $printtime
	if($Language -eq 1036){
        Write-Host "     Importation effectuée en : $printtime."
	    Write-Host
	    Write-Host "(OK) Audit effectué en : $audittime."
	    Write-Host
    }elseif($Language -eq 1033){
        Write-Host "     Importation performed in : $printtime."
        Write-Host
        Write-Host "(OK) Audit performed in : $audittime."
        Write-Host
    }
}